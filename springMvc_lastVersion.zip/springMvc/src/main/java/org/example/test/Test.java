package org.example.test;

public class Test {

	public static void main(String[] args) {


		/// test entity

//		RolesEntity role = new RolesEntity("student");
//		UtilisateurEntity utilisateurs = new UtilisateurEntity();
////		UtilisateurEntity utilisateurs = new UtilisateurEntity("b","b", "n@gmail","123", 0677777, role);
//		TypereservationEntity typeReservation = new TypereservationEntity("samedi", 25, "2021-09-23");
//		ReservationEntity res = new ReservationEntity(false, "2021-09-23", utilisateurs, typeReservation);
//		ApprenantEntity appre = new ApprenantEntity("bb", "bb", "bb@gmail", "123", 0677777, 3, role);
//		AdministrateurEntity admin = new AdministrateurEntity("b", "b", "n@gmail", "123", 0677777, role);
////        ApprenantEntity appre = new ApprenantEntity(3);
////        AdministrateurEntity admin = new AdministrateurEntity();
//
//		// Session session;
//		Session session = null;
//		Transaction transaction = null;
//		try {
//
//			session = HibernateUtil.getSessionFactory().getCurrentSession();
//			transaction = session.beginTransaction();
////			session.persist(user);
//			// lancer des mises à jour dans la session et faire automatiquement le commit
//			// session.flush();
//			session.persist(utilisateurs);
//			session.persist(role);
//			session.persist(res);
//			session.persist(appre);
//			session.persist(admin);
//			session.persist(typeReservation);
//
//			transaction.commit();
//			System.out.println("bien creer !");
//		} catch (Exception e) {
//			if (transaction != null) {
//				transaction.rollback();
//			}
//			e.printStackTrace();
//		} finally {
//			if (session != null) {
//				session.close();
//			}
//
//		}
		
		

		
	}
}
